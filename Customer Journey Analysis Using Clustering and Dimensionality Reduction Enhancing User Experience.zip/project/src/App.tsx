import React, { useState } from 'react';
import { 
  Users, 
  LineChart as LineChartIcon, 
  GitBranch, 
  Filter, 
  Settings, 
  Download, 
  Upload, 
  Plus,
  Save,
  XCircle,
  ChevronDown,
  ChevronUp,
  RefreshCw
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ScatterChart,
  Scatter,
  ZAxis
} from 'recharts';

interface JourneyMetric {
  name: string;
  value: number;
  trend: number;
}

function App() {
  const [activeTab, setActiveTab] = useState('journey');
  
  const journeyMetrics: JourneyMetric[] = [
    { name: 'Engagement Rate', value: 78, trend: 5.2 },
    { name: 'Conversion Rate', value: 42, trend: -2.1 },
    { name: 'Retention Rate', value: 85, trend: 3.8 },
    { name: 'Satisfaction Score', value: 92, trend: 1.5 }
  ];

  const getTrendColor = (trend: number) => {
    if (trend > 0) return 'text-green-600';
    if (trend < 0) return 'text-red-600';
    return 'text-gray-600';
  };

  const journeyData = [
    { month: 'Jan', engagement: 65, conversion: 45, retention: 80 },
    { month: 'Feb', engagement: 70, conversion: 48, retention: 82 },
    { month: 'Mar', engagement: 68, conversion: 52, retention: 85 },
    { month: 'Apr', engagement: 75, conversion: 55, retention: 88 },
    { month: 'May', engagement: 80, conversion: 58, retention: 90 },
    { month: 'Jun', engagement: 85, conversion: 62, retention: 92 }
  ];

  const channelDistribution = [
    { name: 'Mobile App', value: 35 },
    { name: 'Website', value: 25 },
    { name: 'Email', value: 20 },
    { name: 'Social Media', value: 15 },
    { name: 'Phone', value: 5 }
  ];

  const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#3b82f6', '#ec4899'];

  const radarData = [
    { metric: 'Engagement', A: 85, B: 65, C: 45 },
    { metric: 'Retention', A: 92, B: 75, C: 60 },
    { metric: 'Conversion', A: 78, B: 60, C: 40 },
    { metric: 'Satisfaction', A: 88, B: 70, C: 55 },
    { metric: 'Activity', A: 82, B: 68, C: 50 }
  ];

  const dimensionalityData = [
    { x: 82, y: 78, z: 120, name: 'Segment A' },
    { x: 65, y: 55, z: 80, name: 'Segment B' },
    { x: 45, y: 42, z: 50, name: 'Segment C' },
    { x: 70, y: 68, z: 90, name: 'Segment D' },
    { x: 88, y: 82, z: 150, name: 'Segment E' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">Customer Journey Analysis</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  className={`flex items-center px-4 py-2 rounded-lg ${
                    activeTab === 'journey' 
                      ? 'bg-indigo-600 text-white' 
                      : 'text-gray-600 hover:bg-indigo-50'
                  }`}
                  onClick={() => setActiveTab('journey')}
                >
                  <LineChartIcon className="h-5 w-5 mr-2" />
                  Journey
                </button>
                <button
                  className={`flex items-center px-4 py-2 rounded-lg ${
                    activeTab === 'clusters' 
                      ? 'bg-indigo-600 text-white' 
                      : 'text-gray-600 hover:bg-indigo-50'
                  }`}
                  onClick={() => setActiveTab('clusters')}
                >
                  <GitBranch className="h-5 w-5 mr-2" />
                  Clusters
                </button>
                <button
                  className={`flex items-center px-4 py-2 rounded-lg ${
                    activeTab === 'dimensions' 
                      ? 'bg-indigo-600 text-white' 
                      : 'text-gray-600 hover:bg-indigo-50'
                  }`}
                  onClick={() => setActiveTab('dimensions')}
                >
                  <Filter className="h-5 w-5 mr-2" />
                  Dimensions
                </button>
              </div>
              <button className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900">
                <Settings className="h-5 w-5 mr-2" />
                Settings
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'clusters' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Cluster Performance Comparison</h3>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart outerRadius={150} data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="metric" />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} />
                    <Radar name="High-Value" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.3} />
                    <Radar name="Emerging" dataKey="B" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                    <Radar name="Traditional" dataKey="C" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.3} />
                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'journey' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Journey Analytics</h2>
            
            <div className="grid grid-cols-4 gap-6">
              {journeyMetrics.map((metric, index) => (
                <div key={index} className="bg-white rounded-lg shadow-lg p-6">
                  <h3 className="text-lg font-medium text-gray-800 mb-2">{metric.name}</h3>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-bold text-indigo-600">
                      {metric.value}%
                    </div>
                    <div className={`flex items-center ${getTrendColor(metric.trend)}`}>
                      {metric.trend > 0 ? '↑' : metric.trend < 0 ? '↓' : '→'}
                      <span className="ml-1">{Math.abs(metric.trend)}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Journey Trends</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={journeyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="engagement" stroke="#6366f1" strokeWidth={2} />
                      <Line type="monotone" dataKey="conversion" stroke="#10b981" strokeWidth={2} />
                      <Line type="monotone" dataKey="retention" stroke="#f59e0b" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Channel Distribution</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={channelDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                        label
                      >
                        {channelDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg p-6 col-span-2">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Customer Flow Analysis</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={journeyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Area 
                        type="monotone" 
                        dataKey="engagement" 
                        stackId="1" 
                        stroke="#6366f1" 
                        fill="#6366f1" 
                        fillOpacity={0.3}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="conversion" 
                        stackId="1" 
                        stroke="#10b981" 
                        fill="#10b981" 
                        fillOpacity={0.3}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="retention" 
                        stackId="1" 
                        stroke="#f59e0b" 
                        fill="#f59e0b" 
                        fillOpacity={0.3}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'dimensions' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Dimensionality Analysis</h2>
            
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Customer Segment Distribution</h3>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      type="number" 
                      dataKey="x" 
                      name="Engagement Score" 
                      unit="%" 
                      domain={[0, 100]}
                    />
                    <YAxis 
                      type="number" 
                      dataKey="y" 
                      name="Retention Score" 
                      unit="%" 
                      domain={[0, 100]}
                    />
                    <ZAxis 
                      type="number" 
                      dataKey="z" 
                      range={[50, 400]} 
                      name="Revenue"
                    />
                    <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                    <Legend />
                    <Scatter 
                      name="Customer Segments" 
                      data={dimensionalityData} 
                      fill="#6366f1"
                    />
                  </ScatterChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 text-sm text-gray-600">
                <p>Bubble size represents revenue contribution</p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;